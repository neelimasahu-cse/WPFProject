﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MulitipleViews.ViewModels
{
    public class ElectricalsViewModel
    {
    }
}
